  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 2;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (motor_P)
    ;%
      section.nData     = 46;
      section.data(46)  = dumData; %prealloc
      
	  ;% motor_P.Int_L
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% motor_P.InteriorPMSM_Ldq
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% motor_P.InteriorPMSM_P
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 3;
	
	  ;% motor_P.InteriorPMSM_Rs
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 4;
	
	  ;% motor_P.Int_Ts
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 5;
	
	  ;% motor_P.Int_U
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 6;
	
	  ;% motor_P.InteriorPMSM_idq0
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 7;
	
	  ;% motor_P.InteriorPMSM_lambda_pm_calc
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 9;
	
	  ;% motor_P.InteriorPMSM_theta_init
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 10;
	
	  ;% motor_P.Constant_Value
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 11;
	
	  ;% motor_P.Constant1_Value
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 12;
	
	  ;% motor_P.DiscreteTimeIntegrator3_gainval
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 13;
	
	  ;% motor_P.DiscreteTimeIntegrator3_UpperSa
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 14;
	
	  ;% motor_P.DiscreteTimeIntegrator3_LowerSa
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 15;
	
	  ;% motor_P.Constant1_Value_c
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 16;
	
	  ;% motor_P.DiscreteTimeIntegrator3_gainv_i
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 17;
	
	  ;% motor_P.DiscreteTimeIntegrator3_Upper_d
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 18;
	
	  ;% motor_P.DiscreteTimeIntegrator3_Lower_d
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 19;
	
	  ;% motor_P.Gain2_Gain
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 20;
	
	  ;% motor_P.Gain3_Gain
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 21;
	
	  ;% motor_P.Gain1_Gain
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 22;
	
	  ;% motor_P.Gain4_Gain
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 23;
	
	  ;% motor_P.Saturation2_UpperSat
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 24;
	
	  ;% motor_P.Saturation2_LowerSat
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 25;
	
	  ;% motor_P.Gain_Gain
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 26;
	
	  ;% motor_P.Switch_Threshold
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 27;
	
	  ;% motor_P.Gain_Gain_k
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 28;
	
	  ;% motor_P.Gain1_Gain_o
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 29;
	
	  ;% motor_P.Gain4_Gain_n
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 30;
	
	  ;% motor_P.Gain2_Gain_k
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 31;
	
	  ;% motor_P.Gain3_Gain_i
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 32;
	
	  ;% motor_P.Constant1_Value_l
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 33;
	
	  ;% motor_P.Constant2_Value
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 34;
	
	  ;% motor_P.Gain_Gain_f
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 35;
	
	  ;% motor_P.Gain1_Gain_n
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 36;
	
	  ;% motor_P.Constant_Value_i
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 37;
	
	  ;% motor_P.Gain2_Gain_l
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 38;
	
	  ;% motor_P.Constant1_Value_k
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 39;
	
	  ;% motor_P.Constant1_Value_i
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 40;
	
	  ;% motor_P.Constant2_Value_l
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 41;
	
	  ;% motor_P.Constant2_Value_i
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 42;
	
	  ;% motor_P.Constant1_Value_m
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 43;
	
	  ;% motor_P.Constant1_Value_d
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 44;
	
	  ;% motor_P.Constant2_Value_o
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 45;
	
	  ;% motor_P.Constant2_Value_d
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 46;
	
	  ;% motor_P.Constant2_Value_dv
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 47;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% motor_P.Constant1_Value_cx
	  section.data(1).logicalSrcIdx = 46;
	  section.data(1).dtTransOffset = 0;
	
	  ;% motor_P.Constant3_Value
	  section.data(2).logicalSrcIdx = 47;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(2) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 2;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (motor_B)
    ;%
      section.nData     = 90;
      section.data(90)  = dumData; %prealloc
      
	  ;% motor_B.IndexVector
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% motor_B.DiscreteTimeIntegrator3
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% motor_B.UnitDelay
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% motor_B.Switch1
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% motor_B.Gain4
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% motor_B.sine_cosine_o1
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% motor_B.sine_cosine_o2
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% motor_B.Product2
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% motor_B.IndexVector_k
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% motor_B.DiscreteTimeIntegrator3_e
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% motor_B.Product3
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% motor_B.Add1
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% motor_B.Gain2
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% motor_B.Product
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% motor_B.Product1
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% motor_B.Add
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% motor_B.Gain3
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% motor_B.Subtract1
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 17;
	
	  ;% motor_B.Gain1
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 18;
	
	  ;% motor_B.Gain4_j
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 19;
	
	  ;% motor_B.Subtract2
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 20;
	
	  ;% motor_B.Saturation2
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 21;
	
	  ;% motor_B.Sum
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 24;
	
	  ;% motor_B.Gain
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 25;
	
	  ;% motor_B.Sum1
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 26;
	
	  ;% motor_B.Sum2
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 27;
	
	  ;% motor_B.Sum3
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 28;
	
	  ;% motor_B.Switch
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 29;
	
	  ;% motor_B.Product_l
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 30;
	
	  ;% motor_B.Gain_f
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 33;
	
	  ;% motor_B.Gain1_p
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 34;
	
	  ;% motor_B.Gain4_o
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 35;
	
	  ;% motor_B.Add_j
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 36;
	
	  ;% motor_B.Product2_g
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 37;
	
	  ;% motor_B.Gain2_n
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 38;
	
	  ;% motor_B.Gain3_f
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 39;
	
	  ;% motor_B.Add1_h
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 40;
	
	  ;% motor_B.Product3_m
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 41;
	
	  ;% motor_B.Add1_m
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 42;
	
	  ;% motor_B.Product_n
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 43;
	
	  ;% motor_B.Product1_n
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 44;
	
	  ;% motor_B.Add_b
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 45;
	
	  ;% motor_B.Product_j
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 46;
	
	  ;% motor_B.IndexVector_p
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 47;
	
	  ;% motor_B.IndexVector1
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 48;
	
	  ;% motor_B.Add_i
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 49;
	
	  ;% motor_B.Product_b
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 50;
	
	  ;% motor_B.Gain1_f
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 51;
	
	  ;% motor_B.Add_p
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 52;
	
	  ;% motor_B.Gain2_c
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 53;
	
	  ;% motor_B.Product3_i
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 54;
	
	  ;% motor_B.Gain_n
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 55;
	
	  ;% motor_B.Product_ny
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 56;
	
	  ;% motor_B.Product1_p
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 57;
	
	  ;% motor_B.Product2_h
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 58;
	
	  ;% motor_B.Add_e
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 59;
	
	  ;% motor_B.Product11
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 60;
	
	  ;% motor_B.Product12
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 61;
	
	  ;% motor_B.Add2
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 62;
	
	  ;% motor_B.Product4
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 63;
	
	  ;% motor_B.Gain1_pl
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 64;
	
	  ;% motor_B.Gain2_o
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 65;
	
	  ;% motor_B.Add4
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 66;
	
	  ;% motor_B.VectorConcatenate
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 67;
	
	  ;% motor_B.Gain_n0
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 70;
	
	  ;% motor_B.Gain1_m
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 71;
	
	  ;% motor_B.Add_a
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 72;
	
	  ;% motor_B.IndexVector_b
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 73;
	
	  ;% motor_B.Product_c
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 74;
	
	  ;% motor_B.Product_l3
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 75;
	
	  ;% motor_B.IndexVector_f
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 76;
	
	  ;% motor_B.IndexVector1_b
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 77;
	
	  ;% motor_B.Product_g
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 78;
	
	  ;% motor_B.IndexVector_pa
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 79;
	
	  ;% motor_B.Product_m
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 80;
	
	  ;% motor_B.Add_l
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 81;
	
	  ;% motor_B.IndexVector_c
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 82;
	
	  ;% motor_B.Product_d
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 83;
	
	  ;% motor_B.Product_o
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 84;
	
	  ;% motor_B.IndexVector_g
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 85;
	
	  ;% motor_B.IndexVector1_c
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 86;
	
	  ;% motor_B.Product_p
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 87;
	
	  ;% motor_B.IndexVector_bo
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 88;
	
	  ;% motor_B.Product_jy
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 89;
	
	  ;% motor_B.IndexVector_kq
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 90;
	
	  ;% motor_B.Product_g3
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 91;
	
	  ;% motor_B.Add_pf
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 92;
	
	  ;% motor_B.Switch_m
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 93;
	
	  ;% motor_B.Subtract
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 94;
	
	  ;% motor_B.Add1_o
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 95;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% motor_B.Compare
	  section.data(1).logicalSrcIdx = 90;
	  section.data(1).dtTransOffset = 0;
	
	  ;% motor_B.Compare_f
	  section.data(2).logicalSrcIdx = 91;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 2;
    sectIdxOffset = 2;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (motor_DW)
    ;%
      section.nData     = 4;
      section.data(4)  = dumData; %prealloc
      
	  ;% motor_DW.DiscreteTimeIntegrator3_DSTATE
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% motor_DW.UnitDelay_DSTATE
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% motor_DW.DiscreteTimeIntegrator3_DSTAT_k
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% motor_DW.Subtract_DWORK1
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% motor_DW.DiscreteTimeIntegrator3_IC_LOAD
	  section.data(1).logicalSrcIdx = 4;
	  section.data(1).dtTransOffset = 0;
	
	  ;% motor_DW.DiscreteTimeIntegrator3_IC_LO_k
	  section.data(2).logicalSrcIdx = 5;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 4147729004;
  targMap.checksum1 = 1700490298;
  targMap.checksum2 = 4191857582;
  targMap.checksum3 = 2439601148;

